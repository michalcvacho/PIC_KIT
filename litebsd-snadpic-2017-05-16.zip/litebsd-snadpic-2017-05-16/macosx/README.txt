This directory contains a pic32prog binary for Mac OS X.
