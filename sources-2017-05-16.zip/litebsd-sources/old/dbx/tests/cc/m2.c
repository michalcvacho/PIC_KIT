static int i, j;

q ()
{
}
