/*
 * Test of dynamic name resolution.
 */

main ()
{
    int i;

    i = 2;
    p(3);
}

p (j)
int j;
{
    int k;

    k = j;
}
