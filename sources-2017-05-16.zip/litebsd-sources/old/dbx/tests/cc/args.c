/*
 * Test of passing and accessing the command line arguments through dbx.
 */

main (argc, argv)
int argc;
char *argv[];
{
}
