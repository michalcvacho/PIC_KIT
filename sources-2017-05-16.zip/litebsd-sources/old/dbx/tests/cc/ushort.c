struct {
    int a;
    unsigned short s;
    int b;
} u;

main ()
{
    u.s = 0xffff;
}
