/*
 * The user structure is a good test of the general symbol processing
 * abilities of dbx.
 */

#include <sys/param.h>
#include <sys/dir.h>
#include <sys/user.h>

main ()
{
}
