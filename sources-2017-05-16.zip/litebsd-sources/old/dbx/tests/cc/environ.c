main (argc, argv)
{
    printf("argc = %d\n", argc);
}
