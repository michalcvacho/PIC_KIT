type
    OT = integer;
    T = record
	a, b : integer;
    end;

var v : integer;

procedure Blah ; external;
