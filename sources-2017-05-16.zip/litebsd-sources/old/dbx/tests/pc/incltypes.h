type
    RTRec = record
	i, j : integer;
    end;
    RT = ^RTRec;
