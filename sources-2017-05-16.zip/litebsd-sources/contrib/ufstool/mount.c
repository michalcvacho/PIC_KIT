/*
 * Mount 4.4BSD filesystem via FUSE interface.
 *
 * Copyright (C) 2014 Serge Vakulenko, <serge@vak.ru>
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for any purpose and without fee is hereby
 * granted, provided that the above copyright notice appear in all
 * copies and that both that the copyright notice and this
 * permission notice and warranty disclaimer appear in supporting
 * documentation, and that the name of the author not be used in
 * advertising or publicity pertaining to distribution of the
 * software without specific, written prior permission.
 *
 * The author disclaim all warranties with regard to this
 * software, including all implied warranties of merchantability
 * and fitness.  In no event shall the author be liable for any
 * special, indirect or consequential damages or any damages
 * whatsoever resulting from loss of use, data or profits, whether
 * in an action of contract, negligence or other tortious action,
 * arising out of or in connection with the use or performance of
 * this software.
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <unistd.h>
#include <errno.h>

#define FUSE_USE_VERSION 26
#include <fuse.h>

#include "libufs.h"
#include "dir.h"

extern int verbose;

/*
 * Print a message to log file.
 */
static void printlog(const char *format, ...)
{
    va_list ap;

    if (verbose) {
        va_start(ap, format);
        vfprintf(stderr, format, ap);
        va_end(ap);
        fflush(stderr);
    }
}

static dev_t make_rdev(unsigned raw)
{
    return makedev (raw >> 8, raw & 0xff);
}

/*
 * Copy data to struct stat.
 */
static int getstat (ufs_inode_t *inode, struct stat *statbuf)
{
    statbuf->st_mode   = inode->mode & 07777;    /* protection */
    statbuf->st_ino    = inode->number;          /* inode number */
    statbuf->st_nlink  = inode->nlink;           /* number of hard links */
    statbuf->st_uid    = inode->uid;             /* user ID of owner */
    statbuf->st_gid    = inode->gid;             /* group ID of owner */
    statbuf->st_rdev   = 0;                      /* device ID (if special file) */
    statbuf->st_size   = inode->size;            /* total size, in bytes */
    statbuf->st_blocks = inode->blocks;          /* number of blocks allocated */
    statbuf->st_atime  = inode->atime;           /* time of last access */
    statbuf->st_mtime  = inode->mtime;           /* time of last modification */
    statbuf->st_ctime  = inode->ctime;           /* time of last status change */

    switch (inode->mode & IFMT) {               /* type of file */
    case IFREG:                                 /* regular */
        statbuf->st_mode |= S_IFREG;
        break;
    case IFDIR:                                 /* directory */
        statbuf->st_mode |= S_IFDIR;
        break;
    case IFCHR:                                 /* character special */
        statbuf->st_mode |= S_IFCHR;
        statbuf->st_rdev = make_rdev (inode->daddr[0]);
        break;
    case IFBLK:                                 /* block special */
        statbuf->st_mode |= S_IFBLK;
        statbuf->st_rdev = make_rdev (inode->daddr[0]);
        break;
    case IFLNK:                                 /* symbolic link */
        statbuf->st_mode |= S_IFLNK;
        break;
    case IFSOCK:                                /* socket */
        statbuf->st_mode |= S_IFSOCK;
        break;
    default:                                    /* cannot happen */
        printlog("--- unknown file type %#x\n", inode->mode & IFMT);
        return -ENOENT;
    }
    return 0;
}

/*
 * Get file attributes.
 */
int op_getattr(const char *path, struct stat *statbuf)
{
    printlog("--- op_getattr(path=\"%s\", statbuf=%p)\n", path, statbuf);
    ufs_t *disk = fuse_get_context()->private_data;
    ufs_inode_t inode;

    if (ufs_inode_lookup (disk, &inode, path) < 0) {
        printlog("--- search failed\n");
        return -ENOENT;
    }
    return getstat (&inode, statbuf);
}

/*
 * Get attributes from an open file.
 */
int op_fgetattr(const char *path, struct stat *statbuf, struct fuse_file_info *fi)
{
    ufs_inode_t *fh = (ufs_inode_t*) (intptr_t) fi->fh;

    printlog("--- op_fgetattr(path=\"%s\", statbuf=%p, fi=%p)\n",
        path, statbuf, fi);

    if (strcmp(path, "/") == 0)
	return op_getattr(path, statbuf);

    if (! fh)
        return -EBADF;

    return getstat (fh, statbuf);
}

/*
 * File open operation.
 */
int op_open(const char *path, struct fuse_file_info *fi)
{
    ufs_t *disk = fuse_get_context()->private_data;
    int write_flag = (fi->flags & O_ACCMODE) != O_RDONLY;

    printlog("--- op_open(path=\"%s\", fi=%p) flags=%#x \n",
        path, fi, fi->flags);

    ufs_inode_t *fh = calloc (1, sizeof(ufs_inode_t));
    if (! fh) {
        printlog("--- out of memory\n");
        return -ENOMEM;
    }

    if (ufs_inode_lookup (disk, fh, path) < 0) {
        printlog("--- open failed\n");
        free (fh);
        return -ENOENT;
    }
    if (write_flag && (fh->mode & IFMT) == IFDIR) {
        /* Cannot open directory on write. */
        free (fh);
        return -EISDIR;
    }
    if ((fh->mode & IFMT) != IFREG) {
        /* Cannot open special files. */
        free (fh);
        return -ENXIO;
    }
    fi->fh = (intptr_t) fh;
    return 0;
}

/*
 * Create and open a file.
 */
int op_create(const char *path, mode_t mode, struct fuse_file_info *fi)
{
    ufs_t *disk = fuse_get_context()->private_data;

    printlog("--- op_create(path=\"%s\", mode=0%03o, fi=%p)\n",
        path, mode, fi);

    ufs_inode_t *fh = calloc (1, sizeof(ufs_inode_t));
    if (! fh) {
        printlog("--- out of memory\n");
        return -ENOMEM;
    }

    mode &= 07777;
    mode |= IFREG;
    if (ufs_inode_create (disk, fh, path, mode) < 0) {
        printlog("--- create failed\n");
        free (fh);
        return -EIO;
    }
    fi->fh = (intptr_t) fh;
    ufs_inode_truncate (fh, 0);
    fh->mtime = time(0);
    fh->dirty = 1;
    ufs_inode_save (fh, 0);
    return 0;
}

/*
 * Read data from an open file.
 */
int op_read(const char *path, char *buf, size_t nbytes, int64_t offset, struct fuse_file_info *fi)
{
    ufs_inode_t *fh = (ufs_inode_t*) (intptr_t) fi->fh;

    printlog("--- op_read(path=\"%s\", buf=%p, nbytes=%d, offset=%lld, fi=%p)\n",
        path, buf, nbytes, offset, fi);

    if (offset >= fh->size)
        return 0;

    if (nbytes > fh->size - offset)
        nbytes = fh->size - offset;

    if (ufs_inode_read (fh, offset, (unsigned char*) buf, nbytes) < 0) {
        printlog("--- read failed\n");
        return -EIO;
    }
    printlog("--- read returned %u\n", nbytes);
    return nbytes;
}

/*
 * Write data to an open file.
 */
int op_write(const char *path, const char *buf, size_t nbytes, int64_t offset,
	     struct fuse_file_info *fi)
{
    ufs_inode_t *fh = (ufs_inode_t*) (intptr_t) fi->fh;

    printlog("--- op_write(path=\"%s\", buf=%p, nbytes=%d, offset=%lld, fi=%p)\n",
        path, buf, nbytes, offset, fi);

    if (ufs_inode_write (fh, offset, (unsigned char*) buf, nbytes) < 0) {
        printlog("--- read failed\n");
        return -EIO;
    }
    fh->mtime = time(0);
    fh->dirty = 1;
    return nbytes;
}

/*
 * Release an open file.
 */
int op_release(const char *path, struct fuse_file_info *fi)
{
    ufs_inode_t *fh = (ufs_inode_t*) (intptr_t) fi->fh;

    printlog("--- op_release(path=\"%s\", fi=%p)\n", path, fi);

    if (! fh)
        return -EBADF;

    if ((fi->flags & O_ACCMODE) != O_RDONLY)
        ufs_inode_save (fh, 0);
    free (fh);
    fi->fh = 0;
    return 0;
}

/*
 * Change the size of a file
 */
int op_truncate(const char *path, int64_t newsize)
{
    ufs_t *disk = fuse_get_context()->private_data;
    ufs_inode_t inode;

    printlog("--- op_truncate(path=\"%s\", newsize=%lld)\n", path, newsize);

    if (ufs_inode_lookup (disk, &inode, path) < 0) {
        printlog("--- open failed\n");
        return -ENOENT;
    }
    if ((inode.mode & IFMT) != IFREG) {
        /* Cannot truncate special files. */
        return -EINVAL;
    }
    ufs_inode_truncate (&inode, newsize);
    inode.mtime = time(0);
    inode.dirty = 1;
    ufs_inode_save (&inode, 0);
    return 0;
}

/*
 * Change the size of an open file.
 */
int op_ftruncate(const char *path, int64_t offset, struct fuse_file_info *fi)
{
    ufs_inode_t *fh = (ufs_inode_t*) (intptr_t) fi->fh;

    printlog("--- op_ftruncate(path=\"%s\", offset=%lld, fi=%p)\n",
        path, offset, fi);

    if ((fi->flags & O_ACCMODE) == O_RDONLY)
        return -EACCES;

    if ((fh->mode & IFMT) != IFREG) {
        /* Cannot truncate special files. */
        return -EINVAL;
    }
    ufs_inode_truncate (fh, offset);
    fh->mtime = time(0);
    fh->dirty = 1;
    ufs_inode_save (fh, 0);
    return 0;
}

/*
 * Remove a file.
 */
int op_unlink(const char *path)
{
    printlog("--- op_unlink(path=\"%s\")\n", path);
    ufs_t *disk = fuse_get_context()->private_data;
    ufs_inode_t inode;

    /* Get the file type. */
    if (ufs_inode_lookup (disk, &inode, path) < 0) {
        printlog("--- search failed\n");
        return -ENOENT;
    }
    if ((inode.mode & IFMT) == IFDIR) {
        /* Cannot unlink directories. */
        return -EISDIR;
    }

    /* Delete file. */
    if (ufs_inode_delete (disk, &inode, path) < 0) {
        printlog("--- delete failed\n");
        return -EIO;
    }
    ufs_inode_save (&inode, 1);
    return 0;
}

/*
 * Remove a directory.
 */
int op_rmdir(const char *path)
{
    printlog("--- op_rmdir(path=\"%s\")\n", path);
    ufs_t *disk = fuse_get_context()->private_data;
    ufs_inode_t inode, parent;
    char buf [MAXBSIZE], *p;

    /* Get the file type. */
    if (ufs_inode_lookup (disk, &inode, path) < 0) {
        printlog("--- search failed\n");
        return -ENOENT;
    }
    if ((inode.mode & IFMT) != IFDIR) {
        /* Cannot remove files. */
        return -ENOTDIR;
    }
    if (inode.nlink > 2) {
        /* Cannot remove non-empty directories. */
        return -ENOTEMPTY;
    }

    /* Open parent directory. */
    strcpy (buf, path);
    p = strrchr (buf, '/');
    if (p)
        *p = 0;
    else
        *buf = 0;
    if (ufs_inode_lookup (disk, &parent, buf) < 0) {
        printlog("--- parent not found\n");
        return -ENOENT;
    }

    /* Delete directory.
     * Need to decrease a link count first. */
    if (ufs_inode_lookup (disk, &inode, path) < 0) {
        printlog("--- directory not found\n");
        return -ENOENT;
    }
    --inode.nlink;
    ufs_inode_save (&inode, 1);
    if (ufs_inode_delete (disk, &inode, path) < 0) {
        printlog("--- delete failed\n");
        return -EIO;
    }
    ufs_inode_save (&inode, 1);

    /* Decrease a parent's link counter. */
    if (ufs_inode_get (disk, &parent, parent.number) < 0) {
        printlog("--- cannot reopen parent\n");
        return -EIO;
    }
    --parent.nlink;
    ufs_inode_save (&parent, 1);
    return 0;
}

/*
 * Create a directory.
 */
int op_mkdir(const char *path, mode_t mode)
{
    printlog("--- op_mkdir(path=\"%s\", mode=0%3o)\n", path, mode);
    ufs_t *disk = fuse_get_context()->private_data;
    ufs_inode_t dir, parent;
    char buf [MAXBSIZE], *p;

    /* Open parent directory. */
    strcpy (buf, path);
    p = strrchr (buf, '/');
    if (p)
        *p = 0;
    else
        *buf = 0;
    if (ufs_inode_lookup (disk, &parent, buf) < 0) {
        printlog("--- parent not found\n");
        return -ENOENT;
    }

    /* Create directory. */
    mode &= 07777;
    mode |= IFDIR;
    int done = ufs_inode_create (disk, &dir, path, mode);
    if (done < 0) {
        printlog("--- cannot create dir inode\n");
        return -ENOENT;
    }
    if (done == 0) {
        /* The directory already existed. */
        return -EEXIST;
    }
    ufs_inode_save (&dir, 0);

    /* Make parent link '..' */
    strcpy (buf, path);
    strcat (buf, "/..");
    if (ufs_inode_link (disk, &dir, buf, parent.number, IFDIR) < 0) {
        printlog("--- dotdot link failed\n");
        return -EIO;
    }
    if (ufs_inode_get (disk, &parent, parent.number) < 0) {
        printlog("--- cannot reopen parent\n");
        return -EIO;
    }
    ++parent.nlink;
    ufs_inode_save (&parent, 1);
    return 0;
}

/*
 * Create a hard link to a file.
 */
int op_link(const char *path, const char *newpath)
{
    printlog("--- op_link(path=\"%s\", newpath=\"%s\")\n", path, newpath);
    ufs_t *disk = fuse_get_context()->private_data;
    ufs_inode_t source, target;

    /* Find source. */
    if (ufs_inode_lookup (disk, &source, path) < 0) {
        printlog("--- source not found\n");
        return -ENOENT;
    }

    if ((source.mode & IFMT) == IFDIR) {
        /* Cannot link directories. */
        return -EPERM;
    }

    /* Create target link. */
    if (ufs_inode_link (disk, &target, newpath, source.number, source.mode) < 0) {
        printlog("--- link failed\n");
        return -EIO;
    }
    source.nlink++;
    ufs_inode_save (&source, 1);
    return 0;
}

/*
 * Rename a file.
 */
int op_rename(const char *path, const char *newpath)
{
    printlog("--- op_rename(path=\"%s\", newpath=\"%s\")\n", path, newpath);
    ufs_t *disk = fuse_get_context()->private_data;
    ufs_inode_t source, target;

    /* Find source and increase the link count. */
    if (ufs_inode_lookup (disk, &source, path) < 0) {
        printlog("--- source not found\n");
        return -ENOENT;
    }
    source.nlink++;
    ufs_inode_save (&source, 1);

    /* Create target link. */
    if (ufs_inode_link (disk, &target, newpath, source.number, source.mode) < 0) {
        printlog("--- link failed\n");
        return -EIO;
    }

    /* Delete the source. */
    if (ufs_inode_delete (disk, &source, path) < 0) {
        printlog("--- delete failed\n");
        return -EIO;
    }
    ufs_inode_save (&source, 1);
    return 0;
}

/*
 * Create a file node.
 */
int op_mknod(const char *path, mode_t mode, dev_t dev)
{
    printlog("--- op_mknod(path=\"%s\", mode=0%3o, dev=%lld)\n",
        path, mode, dev);
    ufs_t *disk = fuse_get_context()->private_data;
    ufs_inode_t inode;

    /* Check if the file already exists. */
    if (ufs_inode_lookup (disk, &inode, path) == 0) {
        printlog("--- already exists\n");
        return -EEXIST;
    }

    /* Encode a mode bitmask. */
    if (S_ISREG(mode)) {
        mode = (mode & 07777) | IFREG;
    } else if (S_ISCHR(mode)) {
        mode = (mode & 07777) | IFCHR;
    } else if (S_ISBLK(mode)) {
        mode = (mode & 07777) | IFBLK;
    } else
        return -EINVAL;

    /* Create the file. */
    if (ufs_inode_create (disk, &inode, path, mode) < 0) {
        printlog("--- create failed\n");
        return -EIO;
    }
    if (S_ISCHR(mode) || S_ISBLK(mode)) {
        inode.daddr[0] = major(dev) << 8 | minor(dev);
    }
    inode.mtime = time(0);
    inode.dirty = 1;
    if (ufs_inode_save (&inode, 0) < 0) {
        printlog("--- create failed\n");
        return -EIO;
    }
    return 0;
}

/*
 * Read the target of a symbolic link.
 */
int op_readlink(const char *path, char *link, size_t size)
{
    printlog("--- op_readlink(path=\"%s\", link=\"%s\", size=%d)\n",
        path, link, size);
    ufs_t *disk = fuse_get_context()->private_data;
    ufs_inode_t inode;

    /* Open the file. */
    if (ufs_inode_lookup (disk, &inode, path) < 0) {
        printlog("--- file not found\n");
        return -ENOENT;
    }

    if ((inode.mode & IFMT) != IFLNK)
        return -EINVAL;

    /* Leave one byte for the terminating null. */
    if (size > inode.size + 1)
        size = inode.size + 1;
    if (inode.size < disk->d_fs.fs_maxsymlinklen) {
        /* Short symlink is stored in inode. */
        strncpy (link, (char*)inode.daddr, size-1);
    } else if (ufs_inode_read (&inode, 0, (unsigned char*)link, size-1) < 0) {
        printlog("--- read failed\n");
        return -EIO;
    }
    link[size-1] = 0;
    return 0;
}

/*
 * Create a symbolic link.
 */
int op_symlink(const char *path, const char *newpath)
{
    printlog("--- op_symlink(path=\"%s\", newpath=\"%s\")\n", path, newpath);
    ufs_t *disk = fuse_get_context()->private_data;
    ufs_inode_t inode;
    int len, mode;

    /* Check if the file already exists. */
    if (ufs_inode_lookup (disk, &inode, newpath) == 0) {
        printlog("--- already exists\n");
        return -EEXIST;
    }

    /* Create symlink. */
    mode = 0777 | IFLNK;
    if (ufs_inode_create (disk, &inode, newpath, mode) < 0) {
        printlog("--- create failed\n");
        return -EIO;
    }
    ufs_inode_save (&inode, 0);

    len = strlen (path);
    if (len < disk->d_fs.fs_maxsymlinklen) {
        /* Short symlink is stored in inode. */
        strcpy ((char*)inode.daddr, path);
        inode.size = len;

    } else if (ufs_inode_write (&inode, 0, (unsigned char*)path, len) < 0) {
        printlog("--- write failed\n");
        return -EIO;
    }
    inode.mtime = time(0);
    inode.dirty = 1;
    if (ufs_inode_save (&inode, 0) < 0) {
        printlog("--- create failed\n");
        return -EIO;
    }
    return 0;
}

/*
 * Change the permission bits of a file.
 */
int op_chmod(const char *path, mode_t mode)
{
    printlog("--- op_chmod(path=\"%s\", mode=0%03o)\n", path, mode);
    ufs_t *disk = fuse_get_context()->private_data;
    ufs_inode_t inode;

    /* Open the file. */
    if (ufs_inode_lookup (disk, &inode, path) < 0) {
        printlog("--- file not found\n");
        return -ENOENT;
    }

    /* Modify the access mode. */
    inode.mode &= ~07777;
    inode.mode |= mode;
    inode.dirty = 1;
    ufs_inode_save (&inode, 0);
    return 0;
}

/*
 * Change the owner and group of a file.
 */
int op_chown(const char *path, uid_t uid, gid_t gid)
{
    printlog("--- op_chown(path=\"%s\", uid=%d, gid=%d)\n", path, uid, gid);
    ufs_t *disk = fuse_get_context()->private_data;
    ufs_inode_t inode;

    /* Open the file. */
    if (ufs_inode_lookup (disk, &inode, path) < 0) {
        printlog("--- file not found\n");
        return -ENOENT;
    }

    /* Modify the owner and group. */
    inode.uid = uid;
    inode.gid = gid;
    inode.dirty = 1;
    ufs_inode_save (&inode, 0);
    return 0;
}

/*
 * Change the access and/or modification times of a file.
 */
int op_utime(const char *path, struct utimbuf *ubuf)
{
    printlog("--- op_utime(path=\"%s\", ubuf=%p)\n", path, ubuf);
    ufs_t *disk = fuse_get_context()->private_data;
    ufs_inode_t inode;

    /* Open the file. */
    if (ufs_inode_lookup (disk, &inode, path) < 0) {
        printlog("--- file not found\n");
        return -ENOENT;
    }

    /* Modify the access and modification times. */
    inode.atime = ubuf->actime;
    inode.mtime = ubuf->modtime;
    inode.dirty = 1;
    ufs_inode_save (&inode, 0);
    return 0;
}

/*
 * Get file system statistics.
 *
 * The 'f_frsize', 'f_favail', 'f_fsid' and 'f_flag' fields are ignored
 */
int op_statfs(const char *path, struct statvfs *statv)
{
    printlog("--- op_statfs(path=\"%s\", statv=%p)\n", path, statv);
    ufs_t *disk = fuse_get_context()->private_data;

    /* The maximum length in bytes of a file name on this file system. */
    statv->f_namemax = MAXNAMLEN;

    /* The preferred length of I/O requests for files on this file system. */
    statv->f_bsize = disk->d_fs.fs_bsize;
    return 0;
}

/*
 * Possibly flush cached data.
 */
int op_flush(const char *path, struct fuse_file_info *fi)
{
    printlog("--- op_flush(path=\"%s\", fi=%p)\n", path, fi);
    return 0;
}

/*
 * Synchronize file contents.
 * If the datasync parameter is non-zero, then only the user data
 * should be flushed, not the meta data.
 */
int op_fsync(const char *path, int datasync, struct fuse_file_info *fi)
{
    ufs_inode_t *fh = (ufs_inode_t*) (intptr_t) fi->fh;

    printlog("--- op_fsync(path=\"%s\", datasync=%d, fi=%p)\n",
        path, datasync, fi);

    if (datasync == 0 && (fi->flags & O_ACCMODE) != O_RDONLY) {
        if (ufs_inode_save (fh, 0) < 0)
            return -EIO;
    }
    return 0;
}

/*
 * Open directory.
 */
int op_opendir(const char *path, struct fuse_file_info *fi)
{
    printlog("--- op_opendir(path=\"%s\", fi=%p)\n", path, fi);
    return 0;
}

/*
 * Read directory.
 */
int op_readdir(const char *path, void *buf, fuse_fill_dir_t filler, int64_t offset,
	       struct fuse_file_info *fi)
{
    printlog("--- op_readdir(path=\"%s\", buf=%p, filler=%p, offset=%lld, fi=%p)\n",
        path, buf, filler, offset, fi);
    ufs_t *disk = fuse_get_context()->private_data;
    ufs_inode_t dir;
    unsigned char name [MAXBSIZE - 12];
    struct direct dirent;

    if (ufs_inode_lookup (disk, &dir, path) < 0) {
        printlog("--- cannot find path %s\n", path);
        return -ENOENT;
    }

    /* Copy the entire directory into the buffer. */
    for (offset = 0; offset < dir.size; offset += dirent.d_reclen) {
        if (ufs_inode_read (&dir, offset, (unsigned char*) &dirent, 8) < 0) {
            printlog("--- read error at offset %ld\n", offset);
            return -EIO;
        }
        if (dirent.d_ino == 0)
            continue;
        //printlog("--- readdir offset %lu: inum=%u, reclen=%u, namlen=%u\n", offset, dirent.d_ino, dirent.d_reclen, dirent.d_namlen);

        if (ufs_inode_read (&dir, offset+8, name, (dirent.d_namlen + 4) / 4 * 4) < 0) {
            printlog("--- name read error at offset %ld\n", offset+8);
            return -EIO;
        }
        //printlog("--- readdir offset %lu: name='%s'\n", offset, name);

        if (dirent.d_ino != 0) {
            //printlog("calling filler with name %s\n", name);
            name[dirent.d_namlen] = 0;
            if (filler(buf, (char*)name, NULL, 0) != 0) {
                printlog("    ERROR op_readdir filler: buffer full");
                return -ENOMEM;
            }
        }
    }
    return 0;
}

/*
 * Release directory.
 */
int op_releasedir(const char *path, struct fuse_file_info *fi)
{
    printlog("--- op_releasedir(path=\"%s\", fi=%p)\n", path, fi);
    return 0;
}

/*
 * Clean up filesystem.
 * Called on filesystem exit.
 */
void op_destroy(void *userdata)
{
    printlog("--- op_destroy(userdata=%p)\n", userdata);
}

/*
 * Check file access permissions.
 */
int op_access(const char *path, int mask)
{
    printlog("--- op_access(path=\"%s\", mask=0%o)\n", path, mask);

    /* Always permitted. */
    return 0;
}

static struct fuse_operations mount_ops = {
    .access     = op_access,
    .chmod      = op_chmod,
    .chown      = op_chown,
    .create     = op_create,
    .destroy    = op_destroy,
    .fgetattr   = op_fgetattr,
    .flush      = op_flush,
    .fsync      = op_fsync,
    .ftruncate  = op_ftruncate,
    .getattr    = op_getattr,
    .link       = op_link,
    .mkdir      = op_mkdir,
    .mknod      = op_mknod,
    .open       = op_open,
    .opendir    = op_opendir,
    .readdir    = op_readdir,
    .readlink   = op_readlink,
    .read       = op_read,
    .release    = op_release,
    .releasedir = op_releasedir,
    .rename     = op_rename,
    .rmdir      = op_rmdir,
    .statfs     = op_statfs,
    .symlink    = op_symlink,
    .truncate   = op_truncate,
    .unlink     = op_unlink,
    .utime      = op_utime,
    .write      = op_write,
};

int ufs_mount(ufs_t *disk, char *dirname)
{
    char *av[8];
    int ret, ac;

    printf ("Filesystem mounted as %s\n", dirname);
    printf ("Press ^C to unmount\n");

    /* Invoke FUSE to mount the filesystem. */
    ac = 0;
    av[ac++] = "ufstool";
    av[ac++] = "-f";                    /* foreground */
    av[ac++] = "-s";                    /* single-threaded */
    if (verbose > 1)
        av[ac++] = "-d";                /* debug */
    av[ac++] = dirname;
    av[ac] = 0;
    ret = fuse_main(ac, av, &mount_ops, disk);
    if (ret != 0) {
        perror ("fuse_main failed");
        return -1;
    }
    printf ("\nFilesystem %s unmounted\n", dirname);

    /* Save filesystem superblock. */
    disk->d_fs.fs_clean = 1;
    ufs_superblock_write(disk, 0);
    ufs_disk_close(disk);
    return ret;
}
