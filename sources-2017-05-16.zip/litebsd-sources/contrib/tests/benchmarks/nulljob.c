/*
 * Benchmark "null job" program.
 */

main(argc, argv)
	char *argv[];
{

	exit(0);
}
