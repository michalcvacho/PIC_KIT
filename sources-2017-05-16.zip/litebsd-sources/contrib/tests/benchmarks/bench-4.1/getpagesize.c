getpagesize()
{

	return (1024);
}
