#include <stdio.h>

int main()
{
    printf ("Hello, C World!\n");
    return 0;
}
